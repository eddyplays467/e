package com.pickleHead;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.profile.PlayerProfile;
import org.bukkit.Bukkit;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.entity.EntityDamageEvent;

import java.util.UUID;

public class PickleHead extends JavaPlugin implements Listener {

    private static final String SKULL_OWNER = "lemonale467";

    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("PickleHead enabled! Sea Pickle -> lemonale467 head!");
    }

    @Override
    public void onDisable() {
        getLogger().info("PickleHead disabled.");
    }

    // Build the lemonale467 player head
    private ItemStack buildHead() {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) head.getItemMeta();
        PlayerProfile profile = Bukkit.createPlayerProfile(UUID.nameUUIDFromBytes(("OfflinePlayer:" + SKULL_OWNER).getBytes()), SKULL_OWNER);
        meta.setOwnerProfile(profile);
        head.setItemMeta(meta);
        return head;
    }

    // Check if an item is a sea pickle
    private boolean isSeaPickle(ItemStack item) {
        return item != null && item.getType() == Material.SEA_PICKLE;
    }

    // Check if an item is the lemonale467 head
    private boolean isLemonHead(ItemStack item) {
        if (item == null || item.getType() != Material.PLAYER_HEAD) return false;
        SkullMeta meta = (SkullMeta) item.getItemMeta();
        if (meta == null) return false;
        PlayerProfile profile = meta.getOwnerProfile();
        return profile != null && SKULL_OWNER.equalsIgnoreCase(profile.getName());
    }

    // Replace sea pickle in hand with the lemonale467 head
    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        EquipmentSlot hand = event.getHand();
        if (hand == null) return;

        ItemStack item = player.getInventory().getItem(hand);
        if (isSeaPickle(item)) {
            event.setCancelled(true);
            int amount = item.getAmount();
            player.getInventory().setItem(hand, buildHead());
            // Give back extra pickles if stack > 1
            if (amount > 1) {
                ItemStack extra = new ItemStack(Material.SEA_PICKLE, amount - 1);
                player.getInventory().addItem(extra);
            }
            player.sendMessage("§aYou consumed a sea pickle and received the lemonale467 head!");
        }
    }

    // Handle equipping head via inventory click
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        // Delay by 1 tick to let inventory update first
        Bukkit.getScheduler().runTaskLater(this, () -> updateEffect(player), 1L);
    }

    // Handle scrolling to a sea pickle in hotbar
    @EventHandler
    public void onItemHeld(PlayerItemHeldEvent event) {
        Bukkit.getScheduler().runTaskLater(this, () -> updateEffect(event.getPlayer()), 1L);
    }

    // Apply or remove Health Boost based on helmet
    private void updateEffect(Player player) {
        ItemStack helmet = player.getInventory().getHelmet();
        if (isLemonHead(helmet)) {
            player.addPotionEffect(new PotionEffect(
                PotionEffectType.HEALTH_BOOST,
                Integer.MAX_VALUE,
                254, // amplifier 254 = level 255
                false,
                false,
                true
            ));
        } else {
            player.removePotionEffect(PotionEffectType.HEALTH_BOOST);
        }
    }
}
